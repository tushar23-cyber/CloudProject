<?php

include("dbconnection.php");
include("checklogin.php");
check_login();

$username = $_GET['username']; 

$del = mysqli_query($mysqli,"delete from members where username = '$username'");

if($del)
{
    mysqli_close($mysqli); 
    header("location:manage-users.php"); 
    exit;	
}
else
{
    echo "Error deleting record"; 
}
?>