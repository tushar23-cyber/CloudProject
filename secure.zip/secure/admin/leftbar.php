<div class="page-sidebar" id="main-menu">
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <div class="user-info-wrapper">
        <div class="user-info">
        <div class="greeting" style="font-size:14px;">Welcome</div>
        </div>
      </div>
    <ul>	
      <li class="start"> <a href="home.php"> <i class="icon-custom-home"></i> <span class="title">Dashboard</span>  </a> </li>
      <li><a href="change-password.php"><span class="fa fa-file-text-o"></span> Change Password</a></li>
      <li><a href="manage-users.php"><span class="fa fa-users"></span> Manage Users</a></li>
      <li><a href="manage-tickets.php"><span class="fa fa-ticket"></span> Manage Tickets</a></li> 
      <li><a href="user-access-log.php"><span class="fa fa-users"></span>&nbsp;&nbsp;User Access Logs</a></li>                 
    </ul>