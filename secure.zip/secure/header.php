<div class="header navbar navbar-inverse ">
  <div class="navbar-inner">
  <div class="page-title">	
  <div class="username" style="font-size:24px;"><?php echo $_SESSION['username'];?></div>
      <div class="pull-right">
        <ul class="nav quick-section ">
          <li class="quicklinks"> <a data-toggle="dropdown" class="dropdown-toggle  pull-right " href="#" id="user-options">
            <div class="iconset top-settings-dark "></div>
            </a>
            <ul class="dropdown-menu  pull-right" role="menu" aria-labelledby="user-options">
              <li><a href="profile.php"> My Account</a> </li>
              <li class="divider"></li>
              <li><a href="includes/logout.php"><i class="fa fa-power-off"></i>&nbsp;&nbsp;Log Out</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>