<?php
include_once 'includes/register.inc.php';
include_once 'includes/functions.php';
?>

<!DOCTYPE html>
<html>
    <head>
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>

        <meta charset="UTF-8">
        <title>Secure Login: Registration Form</title>
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script>
        <link rel="stylesheet" href="styles/main.css" />
    </head>
    <body class="error-body no-top">
    <div class="container">
    <div class="row login-container column-seperation">
        <div class="col-md-5 col-md-offset-1">
        <h1>Register on Ticketing Tool</h1>
        </div>
        <?php
        if (!empty($error_msg)) {
            echo $error_msg;
        }
        ?>
        <form action="<?php echo esc_url($_SERVER['REQUEST_URI']); ?>" 
                method="post" 
                name="registration_form"
                class="login-form">
                <div class="row">
                <div class="form-group col-md-10">
            Username: <input type='text' 
                name='username' 
                id='username' 
                title="Usernames may contain only digits, upper and lowercase letters and underscores"/><br>
            Email: <input type="text" name="email" id="email" title="Emails must have a valid email format"/><br>
            Password: <input type="password"
                             name="password" 
                             id="password"
                             title="at least one number and one uppercase and lowercase letter, and at least 8 or more characters"/><br>
            Confirm password: <input type="password" 
                                     name="confirmpwd" 
                                     id="confirmpwd" 
                                     title="Your password and confirmation must match exactly"/><br>
            <input type="button" 
                   value="Register" 
                   onclick="return regformhash(this.form,
                                   this.form.username,
                                   this.form.email,
                                   this.form.password,
                                   this.form.confirmpwd);" /> 
                </div>
                </div>                   
        </form>
        <p>Return to the <a href="index.php">login page</a>.</p>
    </div>
    </div>
    </body>
</html>