-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2021 at 04:40 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `secure_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `user_id` int(11) NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`user_id`, `time`) VALUES
(0, '1620603614'),
(0, '1620603673');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `alt_email` varchar(50) DEFAULT NULL,
  `password` char(128) NOT NULL,
  `mobile` int(10) DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `posting_date` timestamp NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `username`, `email`, `alt_email`, `password`, `mobile`, `gender`, `address`, `posting_date`, `status`) VALUES
(5, 'tushar_kaushik', 'tusharkaushik@crm.com', 'tkaushik23.tk@gmail.com', '$2y$10$HDvwRHZEAfx5u.TiUbk1r./lmzYlXXaTYHtP0VLxgejpg5528fOwW', 1234567890, 'm', 'Krishna Apartments Dwarka', '2021-05-09 21:30:17', NULL),
(6, 'test_user', 'testuser@crm.com', 'usertest@crm.com', '$2y$10$fhLcw6VBoXbUHKi76MBd5eqfaePvJIpWuxwBld8RzkxArtCNzEU8y', 987654321, 'f', 'City Center Dublin', '2021-05-10 00:42:17', NULL),
(7, 'azim_sarfaraz', 'azimsarfaraz@crm.com', 'husainazim@ymail.com', '$2y$10$VrAGgMbVfppOSCbgB2SVee01p9EBv9Eb9oWk0p20eK4dvKX3.5A3S', 2147483647, 'm', 'Block KG-1/439\r\nVikas Puri New Delhi-18', '2021-05-10 00:43:45', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `id` int(11) NOT NULL,
  `ticket_id` varchar(11) DEFAULT NULL,
  `username` varchar(300) DEFAULT NULL,
  `subject` varchar(300) DEFAULT NULL,
  `task_type` varchar(300) DEFAULT NULL,
  `prioprity` varchar(300) DEFAULT NULL,
  `ticket` longtext DEFAULT NULL,
  `attachment` varchar(300) DEFAULT NULL,
  `status` varchar(300) DEFAULT NULL,
  `admin_remark` longtext DEFAULT NULL,
  `posting_date` date DEFAULT NULL,
  `admin_remark_date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`id`, `ticket_id`, `username`, `subject`, `task_type`, `prioprity`, `ticket`, `attachment`, `status`, `admin_remark`, `posting_date`, `admin_remark_date`) VALUES
(15, '4', 'azim_sarfaraz', 'Test Ticket', 'billing', NULL, 'Test', NULL, 'closed', 'test', '2021-05-09', '2021-05-09 23:58:18'),
(18, '7', 'azim_sarfaraz', 'Test Ticket 2', 'ot3', NULL, 'Test Ticket 2', NULL, 'closed', 'Closing as Solved', '2021-05-10', '2021-05-10 12:55:14');

-- --------------------------------------------------------

--
-- Table structure for table `usercheck`
--

CREATE TABLE `usercheck` (
  `id` int(11) NOT NULL,
  `logindate` varchar(255) DEFAULT '',
  `logintime` varchar(255) DEFAULT '',
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT '',
  `ip` varbinary(16) DEFAULT NULL,
  `mac` varbinary(16) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usercheck`
--

INSERT INTO `usercheck` (`id`, `logindate`, `logintime`, `user_id`, `username`, `email`, `ip`, `mac`, `city`, `country`) VALUES
(16, '2021/05/10', '12:53:41am', 2, 'azim_sarfaraz', 'azimsarfaraz@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', ''),
(14, '2021/05/10', '12:40:33am', 2, 'azim_sarfaraz', 'azimsarfaraz@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', ''),
(21, '2021/05/10', '01:44:45pm', 7, 'azim_sarfaraz', 'azimsarfaraz@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', ''),
(20, '2021/05/10', '01:43:56am', 7, 'azim_sarfaraz', 'azimsarfaraz@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', ''),
(19, '2021/05/10', '01:42:29am', 6, 'test_user', 'testuser@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', ''),
(18, '2021/05/10', '01:41:06am', 2, 'azim_sarfaraz', 'azimsarfaraz@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', ''),
(17, '2021/05/10', '12:55:09am', 5, 'tushar_kaushik', 'tusharkaushik@crm.com', 0x3a3a31, 0x30412d30302d32372d30302d30302d30, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usercheck`
--
ALTER TABLE `usercheck`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `usercheck`
--
ALTER TABLE `usercheck`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
