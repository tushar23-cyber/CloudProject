<div class="page-sidebar" id="main-menu">
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <div class="user-info-wrapper">
        <div class="user-info">
          <div class="greeting" style="font-size:14px;">Welcome</div>
          <div class="username" style="font-size:12px;"><?php echo $_SESSION['username'];?></div>
        </div>
      </div>
    <ul>	
      <li class="start"> <a href="dashboard.php"> <i class="icon-custom-home"></i> <span class="title">Dashboard</span> <span class="selected"></span>  </a> </li>
      <li><a href="change-password.php"><span class="fa fa-file-text-o"></span> Change Password</a></li>
      <li><a href="profile.php"><span class="fa fa-user"></span> View Profile</a></li>
      <li ><a href="create-ticket.php"><span class="fa fa-ticket"></span> Create Ticket</a></li>
      <li ><a href="view-tickets.php"><span class="fa fa-ticket"></span> View Ticket</a></li>                    
    </ul>

    

    
	