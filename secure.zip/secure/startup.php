<!DOCTYPE html>
<html lang="en">

<head>

  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
  <link href="css/one-page-wonder.css" rel="stylesheet">

</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
    <div class="container">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">User Log In</a>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="admin/index.php">Admin Log In</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <header class="masthead text-center text-white">
    <div class="masthead-content">
      <div class="container">
        <h1 class="masthead-heading mb-0">Ticketing Tool</h1>
        <a href="register.php" class="btn btn-primary btn-x2 rounded-pill mt-10">User Signup</a>
      </div>
    </div>
  </header>
  <footer class="py-1 bg-blackwhite">
    <div class="container">
      <p class="m-0 text-center text-black medium">Copyright &copy; By Tushar & Azim</p>
    </div>
  </footer>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
